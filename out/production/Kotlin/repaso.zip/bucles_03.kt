fun main(){
    print("introduce el número = ")
    val numero = readln().toInt()
    for (i in 1..numero step 2){
        //if(i%2!=0) print("$i,")
        print("$i,")
    }
}