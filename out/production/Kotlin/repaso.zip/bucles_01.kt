fun main(){
    val letra = "a"
    var i = 10
    while (i>0){
        print("$letra ")
        i--
    }
}