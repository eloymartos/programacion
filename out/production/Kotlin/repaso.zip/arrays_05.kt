fun main(){
        val lista = CharArray(10)
        for (i in (0..lista.size-1)){
                print("introduce número = ")
                lista[i]= readln()[0]
        }
        for (i in (lista.size-1).downTo(0)) println(lista[i])
}