fun main(){
    val set_mutable: MutableSet<Int> = mutableSetOf()
    while (set_mutable.size < 5){
        print("introduce el número : ")
        val numero = readln().toInt()
        if (numero !in set_mutable) set_mutable.add(numero)
    }
    for (i in set_mutable) print("$i ")
}