fun main(){
    val opciones = arrayOf(1, 2, 3, 4, 5, 6, 7)
    print("introduce la cadena : ")
    val cadena = readln()
    val lista : MutableList<Char> = mutableListOf()
    for (i in cadena){
        lista.add(i)
    }
    while (true){
        print("1 mostrar la lista\n" +
                "2 insertar caracter en una posición\n" +
                "3 actualizar (modificar) carácter en una posición)\n" +
                "4 borrar caracter en una posición\n" +
                "5 borrar caracter por valor (primera concurrencia)\n" +
                "6 modificar (reemplazar) todas las concurrencias de un valor por otro\n" +
                "7 salir\n")
        var respuesta = readln().toInt()
        while (respuesta !in opciones){
            print("respuesta incorrecta\n" +
                    "1 mostrar la lista\n" +
                    "2 insertar caracter en una posición\n" +
                    "3 actualizar (modificar) carácter en una posición)\n" +
                    "4 borrar caracter en una posición\n" +
                    "5 borrar caracter por valor (primera concurrencia)\n" +
                    "6 modificar (reemplazar) todas las concurrencias de un valor por otro\n" +
                    "7 salir\n")
            respuesta = readln().toInt()
        }
        if (respuesta == 1){
            println(lista.toString())
        }else if (respuesta == 2){
            print("caracter : ")
            val caracter = readln()[0]
            print("posicion : ")
            val posicion = readln().toInt()
            lista.add(posicion, caracter)
        }else if (respuesta == 3){
            print("caracter : ")
            val caracter = readln()[0]
            print("posicion : ")
            val posicion = readln().toInt()
            lista[posicion] = caracter
        }else if (respuesta == 4){
            print("posicion : ")
            val posicion = readln().toInt()
            lista.removeAt(posicion)
        }else if (respuesta== 5){
            print("caracter : ")
            val caracter = readln()[0]
            lista.remove(caracter)
        }else if (respuesta == 6){
            print("caracter a reemplazar : ")
            val viejo = readln()[0]
            print("caracter nuevo : ")
            val nuevo = readln()[0]
            for (i in lista.indices) if (lista[i] == viejo) lista[i] = nuevo
        }else if (respuesta == 7){
            println("nos vimo")
            break
        }else println("me da a mi que tas equivocao en algo")
    }
}