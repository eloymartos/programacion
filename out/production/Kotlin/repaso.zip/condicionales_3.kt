fun main() {
    print("introduce tu edad : ")
    val edad = readln().toInt()
    print("introduce tus ingresos mensuales : ")
    val ingresos = readln().toInt()
    if(edad>=16 && ingresos>=1000) print("debes tributar") else print("no debes tributar")
}