fun main() {
    print("introduce tu edad : ")
    val valor = readln().toInt()
    if(valor>=10) println("eres mayor de edad") else println("eres menor de edad")
}