fun main(){
    print("cuántos decimales quieres ? ")
    val entrada = readln().toInt()
    var lista = IntArray(entrada, {0})
    for ((indice,valor) in lista.withIndex()) {
        print("introduce el valor que quieres en la posición " + (indice + 1) + " : ")
        lista[indice] = readln().toInt()
    }
    for ((indice,valor) in lista.withIndex()) println("$indice $valor")
}