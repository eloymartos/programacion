fun main(){
    val opciones = arrayOf(1, 2, 3, 4, 5, 6, 7)
    print("introduce la cadena : ")
    var palabra = ""
    val cadena = readln()
    val lista : MutableList<String> = mutableListOf()
    for (i in cadena.indices){
        if (cadena[i].toString() == " " || i == cadena.length-1) {
            if (i == cadena.length-1) palabra += cadena[i]
            lista.add(palabra)
            palabra = ""
            continue
        }
        palabra += cadena[i]
    }

    while (true) {
        print(
            "1 mostrar la lista\n" +
                    "2 insertar palabra en una posición\n" +
                    "3 actualizar (modificar) palabra en una posición)\n" +
                    "4 borrar palabra en una posición\n" +
                    "5 borrar palabra por valor (primera concurrencia)\n" +
                    "6 modificar (reemplazar) todas las concurrencias de un valor por otro\n" +
                    "7 salir\n"
        )
        var respuesta = readln().toInt()
        while (respuesta !in opciones) {
            print(
                "respuesta incorrecta\n" +
                        "1 mostrar la lista\n" +
                        "2 insertar caracter en una posición\n" +
                        "3 actualizar (modificar) carácter en una posición)\n" +
                        "4 borrar caracter en una posición\n" +
                        "5 borrar caracter por valor (primera concurrencia)\n" +
                        "6 modificar (reemplazar) todas las concurrencias de un valor por otro\n" +
                        "7 salir\n"
            )
            respuesta = readln().toInt()
        }
        if (respuesta == 1){
            println(lista.toString())
        }else if (respuesta == 2){
            print("palabra : ")
            val palabra = readln()
            print("posicion : ")
            val posicion = readln().toInt()
            lista.add(posicion, palabra)
        }else if (respuesta == 3){
            print("palabra : ")
            val palabra = readln()
            print("posicion : ")
            val posicion = readln().toInt()
            lista[posicion] = palabra
        }else if (respuesta == 4){
            print("posicion : ")
            val posicion = readln().toInt()
            lista.removeAt(posicion)
        }else if (respuesta== 5){
            print("palabra : ")
            val palabra = readln()
            lista.remove(palabra)
        }else if (respuesta == 6){
            print("palabra a reemplazar : ")
            val viejo = readln()
            print("palabra nueva : ")
            val nuevo = readln()
            for (i in lista.indices) if (lista[i] == viejo) lista[i] = nuevo
        }else if (respuesta == 7){
            println("nos vimo")
            break
        }else println("me da a mi que tas equivocao en algo")
    }
}