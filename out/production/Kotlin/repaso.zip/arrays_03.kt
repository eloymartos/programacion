fun main(){
    var i = 0
    val lista = IntArray(10)
    while (i<10){
        print("introduce un valor menor que 0 : ")
        var valor = readln().toInt()
        while (valor>=0){
            print("valor incorrecto, introduzca de nuevo : ")
            valor = readln().toInt()
        }
        lista[i] = valor
        i++
    }
    for ((indice, valor) in lista.withIndex()) println("posición " +(indice+1)+ ", valor $valor")
}