fun main(){
    val lista = IntArray(10)
    for (i in lista.indices){
        var valor = (0..10).random()
        while (valor in lista) valor = (0..10).random()
        lista[i] = valor
    }
    println("\npares = ")
    for (i in lista) if (i%2 == 0) println(i)
    println("\nimpares = ")
    for (i in lista) if (i%2 != 0) println(i)
}