fun main(){
    val lista = mutableMapOf<String, Double>()
    for (i in 1..12){
        print("introduce producto : ")
        val producto = readln()
        print("introduce el precio del/la $producto : ")
        val precio = readln().toDouble()
        lista.put(producto, precio)
        println("has introducido $i productos")
    }
    while (true){
        println("qué quieres hacer ahora ?\n1: borrar producto\n2: añadir nuevo producto\n3: actualizar producto\n4: salir ")
        val respuesta = readln().toInt()
        when (respuesta){
            1-> {
                print("nombre del producto : ")
                val producto = readln()
                if (lista.containsKey(producto)) lista.remove(producto) else println("clave no existente")
            }
            2-> {
                print("introduce producto : ")
                val producto = readln()
                print("introduce el precio del/la $producto : ")
                val precio = readln().toDouble()
                if (lista.containsKey(producto)) println("producto ya existente") else lista.put(producto, precio)
            }
            3-> {
                print("introduce producto : ")
                val producto = readln()
                print("introduce el precio del/la $producto : ")
                val precio = readln().toDouble()
                if (lista.containsKey(producto)) lista.replace(producto, precio) else println("producto no existente")
            }
            4-> break
        }
    }
    var total = 0.0
    for (comodin in 1..3){
        print("introduce producto : ")
        val producto = readln()
        print("introduce la cantidad de $producto a comprar : ")
        val cantidad = readln().toInt()
        total += cantidad * (lista.getOrDefault(producto, 0.0))
    }
    println("el total es : $total")
}