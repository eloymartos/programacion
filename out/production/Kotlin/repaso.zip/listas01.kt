fun main(){
    val lista = listOf("pepe", "carlos", "mariano", "juanca", "ismael")
    for (i in lista) println("$i")
}