fun main(){
    print("introduce tu edad : ")
    val edad = readln().toInt()
    for (i in 1..edad){
        println(i)
    }
}