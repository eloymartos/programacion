fun main(){
    val lista = IntArray(5)
    for (i in lista.indices){
        lista[i] = (0..10).random()
    }
    var min = 11
    var max = -1
    for (i in lista){
        max = if (i>max) i else max
        if (i<min) min = i
    }
    println(max)
    println(min)
}