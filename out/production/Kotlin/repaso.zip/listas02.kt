fun main(){
    val lista : MutableList<Int> = mutableListOf()
    while (lista.size < 5){
        print("introduce número : ")
        val valor = (readln().toInt())
        if (valor !in lista) lista.add(valor)
    }
    print(lista.toString())
}