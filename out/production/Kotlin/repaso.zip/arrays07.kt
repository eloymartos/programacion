fun main(){
    val miarray = IntArray(50)
    val posibilidades = arrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 0)
    for (i in miarray.indices) miarray[i] = (0..100).random()
    while (true) {
        print("qué quieres hacer? \n 1. mostrar vector\n 2. mostrar en orden inverso\n 3. Buscar el número menor.\n 4. Buscar el número mayor.\n 5. Comprobar si existe un número en el vector.\n 6. Cambiar el valor almacenado en una posición.\n 7. Sustituir todas las apariciones de un número por otro\n 8. Intercambiar los valores de 2 posiciones.\n 9. Ordenar el vector de menor a mayor (sin mostrarlo)\n 0. Salir \n")
        var respuesta = readln().toInt()
        while (respuesta !in posibilidades) {
            print("respuesta incorrecta, qué quieres hacer? \n 1.mostrar vector\n 2.mostrar en orden inverso\n 3. Buscar el número menor.\n 4. Buscar el número mayor.\n 5. Comprobar si existe un número en el vector.\n 6. Cambiar el valor almacenado en una posición.\n 7. Sustituir todas las apariciones de un número por otro\n 8. Intercambiar los valores de 2 posiciones.\n 9. Ordenar el vector de menor a mayor (sin mostrarlo)\n 0. Salir \n")
            respuesta = readln().toInt()
        }
        if (respuesta == 1) {
            for (i in miarray.indices) {
                print(miarray[i])
                print(" ")
            }
        } else if (respuesta == 2) {
            for (i in (miarray.size - 1).downTo(0)) println(miarray[i])
        } else if (respuesta == 3) {
            println(miarray.min())
        } else if (respuesta == 4) {
            println(miarray.max())
        } else if (respuesta == 5) {
            print("numero? : ")
            val numero = readln().toInt()
            if (numero in miarray) println("está en la lista") else println("numero no en la lista")
        } else if (respuesta == 6) {
            print("posición a cambiar ? : ")
            val posicion = readln().toInt()
            print("valor a darle ? : ")
            val numero = readln().toInt()
            miarray[posicion] = numero
        }else if (respuesta == 7){
            print("numero a cambiar ? : ")
            val original = readln().toInt()
            print("valor a darle ? : ")
            val nuevo = readln().toInt()
            for (i in miarray.indices) if (miarray[i] == original) miarray[i] = nuevo
        }else if (respuesta == 8){
            print("primera posicion ? : ")
            var primera = readln().toInt()
            print("segunda posicion ? : ")
            var segunda = readln().toInt()
            var comodin = miarray[primera]
            miarray[primera] = miarray[segunda]
            miarray[segunda] = comodin
        }else if (respuesta == 9){
            miarray.sort()
        }
    }
}