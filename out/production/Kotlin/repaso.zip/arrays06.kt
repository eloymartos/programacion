fun main(){
    val lista = IntArray(10)
    for (i in (1..lista.size)){
        print("introduce una posición")
        var posicion = readln().toInt()
        print("introduce un número")
        var valor = readln().toInt()
        while ( posicion < 0 || valor <= 0 || lista[posicion] != 0){
            print("empezamos de nuevo esta, introduce una posición")
            posicion = readln().toInt()
            print("introduce un número")
            valor = readln().toInt()
        }
        lista[posicion] = valor
    }
    for ((i,x) in lista.withIndex()) println("$i = $x")

}