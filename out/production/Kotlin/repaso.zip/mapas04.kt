fun main(){
    val empleados = mutableMapOf<String, Any>()
    empleados.put("46266616t", "eloy martos cobos")
    empleados.put("91204932q", "isabel pantoja mosquera")
    empleados.put("94629263o", "diamante pal fri")
    empleados.put("52825289i", "carlos ortega fernandez")
    empleados.put("12345678K", "la dis lao")
    for ((v, c) in empleados){
        println("emplead@ $c con dni $v")
    }
}